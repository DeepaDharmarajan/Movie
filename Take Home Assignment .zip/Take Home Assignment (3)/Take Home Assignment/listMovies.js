// src/components/MovieList.js
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import './MovieList.css'; // You can create this CSS file for styling

function MovieList() {
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    fetch('/api/movies')
      .then(res => res.json())
      .then(data => setMovies(data))
      .catch(err => console.error("Error fetching movies:", err));
  }, []);

  return (
    <div>
      <h1>Movie List</h1>
      <div className="movie-grid">
        {movies.map(movie => (
          <div key={movie.id} className="movie-card">
            <h3>{movie.title}</h3>
            <p>{movie.tagline}</p>
            <p>Rating: {(movie.vote_average / 10).toFixed(1)}</p>
            <Link to={`/movie/${movie.id}`}>View Details</Link>
          </div>
        ))}
      </div>
    </div>
  );
}

export default MovieList;
